    function computerAI2() //computer "smart" guesses
    {  
        var testing = null;

        switch(parseInt(computer.currentState))
        {    

            case 0:     // randome guess state
                
                makeRandomGuess();
                
                if(player1.damageShipAtXandY(computer.x, computer.y) === true)
                {   
                    computer.currentState = 1;
                    computer.firstHitX = computer.x;
                    computer.firstHitY = computer.y;
                }

                break;

            case 1:     // first guess was a hit                
                
                // after first hit get random  

                switch (computer.direction) 
                {
                    case 0:     //top position
                        computer.y--;
                        break;
                    case 1:     //right position
                        computer.x++;
                        break;
                    case 2:     //bottom position
                        computer.y++;
                        break;
                    case 3:     //left position
                        computer.x--;
                        break;

                }
                
                //Boundary checking for computer guesses
                
                while(computer.x < 0 || computer.x > 9 || computer.y < 0 || computer.y > 9 || (checkGuess(computer.x, computer.y) === true))
                {
                    computer.x = computer.firstHitX;
                    computer.y = computer.firstHitY;
                    computer.direction++;
                    
                    switch (computer.direction) 
                    {
                        case 0:     //top position
                            computer.y--;
                            break;
                        case 1:     //right position
                            computer.x++;
                            break;
                        case 2:     //bottom position
                            computer.y++;
                            break;
                        case 3:     //left position
                            computer.x--;
                            break;

                    }
                    
                    
                    if(computer.direction >= 3)
                    {        
                        computer.currentState = 0;
                        computer.direction = 0;
                        makeRandomGuess();
                        break;
                    }
                    
                }
                        

                if(player1.damageShipAtXandY(computer.x, computer.y) === true) // if you did get a hit
                {   
                    computer.currentState = 2;   
                }else // if you didn't get a hit
                {

                    if(computer.direction >= 3){
                        computer.currentState = 0;
                        computer.direction = 0;
                    }else
                    {
                        computer.x = computer.firstHitX;
                        computer.y = computer.firstHitY;
                        computer.direction++; 
                    }
                }

                break;

            case 2:

                switch (computer.direction) 
                {
                    case 0:     //top position
                        computer.y--;
                        break;
                    case 1:     //right position
                        computer.x++;
                        break;
                    case 2:     //bottom position
                        computer.y++;
                        break;
                    case 3:     //left position
                        computer.x--;
                        break;

                }
                
                
                if(computer.x < 0 || computer.x > 9 || computer.y < 0 || computer.y > 9 || checkGuess(computer.x, computer.y) == true)
                {
                        computer.direction = 0;
                        
                        makeRandomGuess();
                    
                        if(player1.damageShipAtXandY(computer.x, computer.y) === true)
                        {   
                            computer.currentState = 1;
                        }else
                        {     
                            computer.currentState = 0;
                            computer.direction = 0;
                            //document.getElementById(computer.x+"-"+computer.y).src = "Images/White.png";
                        }
                    
                }else if(player1.damageShipAtXandY(computer.x, computer.y) === true)
                {   
                 
                }else
                {     
                    computer.currentState = 0;
                    computer.direction = 0;
                    //document.getElementById(computer.x+"-"+computer.y).src = "Images/White.png";
                }
                
                break;


        } //end switch

        
        computer.guesses[parseInt(computer.numGuesses)] = "" + computer.x + "" + computer.y + "";
        computer.numGuesses++;
        switchPlayerTurn();
        

        if(player1.isDefeated())
        {
            gameOver = true;
            alert("Computer Wins!!!");
            return;
        }
    
    }// End AI function



    function playerGuess(xCoord, yCoord)
    {

        if(playerTurn)
        {
            document.getElementById("op"+xCoord+"-"+yCoord).onclick = "";
            
            if(computer.damageShipAtXandY(xCoord, yCoord) == true)
            {
               if(computer.isDefeated())
                {
                    gameOver = true;
                    alert("player1 you win");
                    return;
                } 
                
            }
        
                switchPlayerTurn();
                computerAI2();
        
        }

    }
    


    function makeRandomGuess()
    {
        
        var randomX = randomGenerator(0,10);
            var randomY = randomGenerator(0,10);
        
        computer.x = randomX;
        computer.y = randomY;
        
        if(checkGuess(computer.x, computer.y) === true)
        {
            for(var g = 0; g < 10; g++)
            {
                if(checkGuess(computer.x, computer.y) === true)
                    computer.x = parseInt(parseInt(computer.x + 1) % 10);            
                else
                    return;
                    
            }
            
            computer.x = randomX;
            
            for(var g = 0; g < 10; g++)
            {
                if(checkGuess(computer.x, computer.y) === true)
                    computer.y = parseInt(parseInt(computer.x + 1) % 10);            
                else
                    return;
            }
            
        }
    }


    function checkGuess(xCoord, yCoord)
    {
        for(var i = 0; i < parseInt(computer.numGuesses); i++)
        {
            if(computer.guesses[i] === ("" + xCoord + "" + yCoord))
            {
                alert("value found");
                return true;
            }
        }
        
        return false;
    }   



