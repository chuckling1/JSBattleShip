 var player1;
        var computer;
        var playerTurn = true;
        var gameOver = false;
        var numShipsPlaced = 0;
            
            
        function switchPlayerTurn()
        {
            
            if(playerTurn)
            {
                playerTurn = false;
            }else
            {
                playerTurn = true;
            }
                   
        }    
        
        
        function allowDrop(ev){ ev.preventDefault(); }

        function handleEvent(ev)
        {
            ev.preventDefault();
            
            //Get 
            var srcId = ev.dataTransfer.getData("src");
            var srcImage = document.getElementById(srcId);   
            var target = ev.currentTarget.id;
            var ship = player1.getShip(srcId);

            var targetX = target.charAt(parseInt(0));
            var targetY = target.charAt(parseInt(target.length-1));
            
            if(placeShip(ship, targetX, targetY, "")){
                removeImage(srcImage);
                numShipsPlaced++;
            }
            
            if(numShipsPlaced >= 5)
            {
                
                var mainDiv = document.getElementById("mainDiv");
                var cannonDiv = document.getElementById("cannonDiv");
                var opDiv = document.getElementById("opDiv");
                var displayDiv = document.getElementById("displayDiv");
                
                setTimeout(function () { mainDiv.style.float = "left"; displayDiv.innerHTML = ""; }, 250);
                
                
                setTimeout(
                    function () 
                        { 
                            mainDiv.style.position = "absolute";
                            mainDiv.style.left = "100px";
                            mainDiv.style.top = "75px";
                            
                            
                            cannonDiv.style.display = "inline-block"; 
                            opDiv.style.display = "inline-block"; 
                            document.body.style.backgroundImage = 'url("Images/background.png")'; 
                            opDiv.style.position = "absolute";
                            opDiv.style.right = "100px";
                            opDiv.style.top = "75px";
                        }, 750);
            }
            
            
            
        }
            
        
        function removeImage(imageObject){ imageObject.parentNode.removeChild(imageObject); }    
            
        function drag(ev){ ev.dataTransfer.setData("src", ev.target.id); }    
            
            
        function handleKeyBoardEvent(ev)
        {
            if(ev.keyCode == "32")
                rotateImage(document.activeElement);
        }    
            
            
        function rotateImage(imageObject)
        {
            var ship = player1.getShip(imageObject.id);
             
            
            
            if(ship.orientation == "H")
            {
                imageObject.style.transform = "rotate(90deg)";
                ship.switchOrientation();
            }else
            {
                imageObject.style.transform = "rotate(180deg)";
                ship.switchOrientation();
            }
            
           
                
            
        }
            
        function placeShip(shipObject, xCoord, yCoord, flag)
        {            
            
            if(isSpaceOccupied(xCoord, yCoord, flag) === true)
            {
                //cannot place ship there
                return false;
            }else
            {
                
               shipObject.fillImageArrays();
                
                if(shipObject.orientation === "H")
                {   
                    
                    if(parseInt(parseInt(xCoord) + parseInt(shipObject.SIZE)) > parseInt(10)){ return false; }
                    
                    for(var i = 0; i < shipObject.SIZE; i++)
                    {
                        if(isSpaceOccupied(parseInt(parseInt(xCoord)+parseInt(i)), yCoord, flag) === true)
                        {
                            //cannot place ship there
                            return false;
                        }
                    } 
                   
                    for(var i = 0; i < shipObject.SIZE; i++)
                    {
                        var tempIdString = flag + parseInt(parseInt(xCoord)+parseInt(i)) + "-" + yCoord;
                        var temp = document.getElementById(tempIdString);
                        
                        temp.setAttribute("src", shipObject.cells[i].src);
                        
                     
                        
                        
                        shipObject.cells[i].setXandY(parseInt(parseInt(xCoord)+parseInt(i)), parseInt(yCoord));
                
                      
                    }
                    
                }else
                {   
                    if(parseInt(parseInt(yCoord) + parseInt(shipObject.SIZE)) > parseInt(10)){ return false; }
                    
                    for(var i = 0; i < shipObject.SIZE; i++)
                    {
                        if(isSpaceOccupied(xCoord, parseInt(parseInt(yCoord)+parseInt(i)), flag) === true)
                        {
                            //cannot place ship there
                            return false;
                        }
                    }
                    
            
                    for(var i = 0; i < shipObject.SIZE; i++)
                    {
                        tempIdString = flag + xCoord + "-" + parseInt(parseInt(yCoord)+parseInt(i));                              
                        temp = document.getElementById(tempIdString);
                        temp.setAttribute("src", shipObject.cells[i].src);
                        
                        shipObject.cells[i].setXandY(parseInt(xCoord), parseInt(parseInt(yCoord)+parseInt(i)));
                        
                    }
                
                }
            }
            
            
            shipObject.x = xCoord;
            shipObject.y = yCoord;
            return true;
            
        } //end placeShip


        function isSpaceOccupied(xCoord, yCoord, flag)
        {    
            
            var temp = document.getElementById(flag + xCoord + "-" + yCoord);
                temp = temp.src.substr(parseInt(temp.src.length-9), 9);

            if(temp !== "blank.png"){ return true; }
            else{ return false; }
            
        } //end isSpaceOccupied
            
            
            
        
        function randomGenerator (low, high) {
            return Math.floor((Math.random()*high) + low);
        } 