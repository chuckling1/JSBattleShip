    function initializeGame()
    {
        player1 = new Player();     // create player1 

        var table;

        for(var outer = 0; outer < 2; outer++)
        {
            table = "<table background='Images/WaterBackground.png' style='display:inline-block; '>";
            for(var i = -1; i < 10; i++)
            {
                table += "<tr>";        //start a row

                if(i == parseInt(-1))
                {    
                    for(var rowNegative = 0; rowNegative < 11; rowNegative++)
                    {
                        table += "<td>";
                        table += "<img src='Images/blank.png' />";
                        table += "</td>";
                    }            
                    table += "</tr>";
                }else
                {
                    table += "<td>";
                    table += "<img src='Images/blank.png' />";
                    table += "</td>";  

                    for(var j = 0; j < 10; j++)
                    {
                      table += "<td>";                  //add table data

                        if(playerTurn)
                        {    
                            table += "<img id='" + j + "-" + i + "' src='Images/blank.png' ondrop='handleEvent(event)' ondragover='allowDrop(event)' />";
                        }else
                        {
                            table += "<img id='op" + j + "-" + i + "' src='Images/blank.png' onclick='playerGuess(" + j + ", " + i + ")'/>";
                        }
                      table += "</td>";                 //end table data
                    }

                    table += "</tr>";       //end a row
                }
            }

            table += "</table>";        // end the table

            if(playerTurn)
            {
                document.getElementById("mainDiv").innerHTML = table;       //display it to its div
                switchPlayerTurn();
            }else
            {
                document.getElementById("opDiv").innerHTML = table;
            }
        }

        document.onkeypress = handleKeyBoardEvent;

        randomizeComputerBoard(); 

    } //end initialize game


    function randomizeComputerBoard()
        {
            
            computer = new Computer();
            
            var randomX, randomY, coinFlip;
            var shipPlaced = false;
            
            for(var i = 0; i < parseInt(computer.pieces); i++)
            {
                randomX = randomGenerator(0,10);
                randomY = randomGenerator(0,10);
                coinFlip = (Math.floor(Math.random()*2) === 0);
                
                if(coinFlip){ computer.shipArray[i].switchOrientation(); }
                
                shipPlaced = placeShip(computer.shipArray[i], randomX, randomX, "op");
                
                while(shipPlaced === false)
                {
                    randomX = randomGenerator(0,9);
                    randomY = randomGenerator(0,9);  
                    shipPlaced = placeShip(computer.shipArray[i], randomX, randomX, "op");
                    
                }
            } 
            
            switchPlayerTurn();
                
        }// end randomizeComputerBoard