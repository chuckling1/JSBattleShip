    function Player() 
    { 
        this.pieces = 5;            
        this.carrier = new Carrier();
        this.battleship = new Battleship();
        this.cruiser = new Cruiser();
        this.submarine = new Submarine();
        this.destroyer = new Destroyer();
        this.shipArray = [ this.carrier, this.battleship, this.cruiser, this.submarine, this.destroyer ];

        this.getShip = 
            function(sType)
            {
                if(sType == "carrier")
                {
                    return this.carrier;
                }else if(sType == "battleship")
                {
                    return this.battleship;
                }else if(sType == "cruiser")
                {
                    return this.cruiser;
                }else if(sType == "submarine")
                {    
                    return this.submarine;
                }else if(sType == "destroyer")
                {
                    return this.destroyer;
                }else
                {
                    return null;
                }   
            };

        
        this.isDefeated = 
            function ()
            {
                return this.pieces <= 0;
            };
        
         this.damageShipAtXandY = 
            function (xCoord, yCoord)
            {
             
               var tempShip = this.getShipAtXandY(xCoord, yCoord);
            
               
             try{
                 
                 var tempCell = tempShip.getCell(xCoord, yCoord);
             }catch(e)
             {
                if(playerTurn){
                    document.getElementById("op"+xCoord+"-"+yCoord).src = "Images/White.png";
                }else
                {
                     document.getElementById(""+xCoord+"-"+yCoord).src = "Images/White.png";
                }
                 
                return false;   
             }
             
            if(tempShip.getCell(xCoord, yCoord) != null)
            {
                var tempCell = tempShip.getCell(xCoord, yCoord);


                tempShip.damage++;
                tempCell.damageCell();
                
                if(tempShip.isDestroyed() == true)
                {
                    this.pieces--;
                }
                return true;
            }
             
                
            };
         
         
         this.getShipAtXandY =
                function (xCoord, yCoord)
                {
                    for(var i = 0; i < this.pieces; i++)
                    {
                        if(this.shipArray[i].getCell(xCoord, yCoord) != null)
                        {
                            
                            
                            //alert("ship is " + this.shipArray[i]);
                            return this.shipArray[i];
                        }
                    }
             
                    return null;
                };
        
    }// End Player 
         

    function Computer()
    {
        Player.call(this);
        this.direction = 0;      // manages the orientation (top,left, right, bottom)
        this.currentState = 0;   // currentState of AI F.S.M.
        this.x = -1;
        this.y= -1;    //keeps the coordinates
        this.firstHitX = -1;
        this.firstHitY = -1;
        this.numGuesses = 0;
        this.guesses = new Array(100);
    }    


    function Piece(pieceSize) 
    {
        
        // Attributes
        this.SIZE = pieceSize;
        this.damage = 0;
        this.orientation = "H";
        this.shipType = "ship";
        this.x = -1;
        this.y = -1;
        this.cells = [this.SIZE];
        
        
        // Methods
        this.fillImageArrays = 
            function ()
             {
                for(var i = 0; i < parseInt(this.SIZE); i++)
                {  
                    if(playerTurn)
                    {
                        this.cells[i] = new Cell("Images/" + this.shipType + "/" + this.shipType + "" + this.orientation + i + ".png");

                    }else
                    {
                        this.cells[i] = new Cell("Images/FakeBlank.png");
                    } 
                }
             };

        this.switchOrientation = 
            function()
            {
                if(this.orientation === "H")
                {
                    this.orientation = "V";
                }else
                {
                    this.orientation = "H";
                }
            };

        this.toString = function() { return "I'm a " + this.shipType + " and my size is " + this.SIZE + " and my damage is " + this.damage; };

        this.getDamage = function () { return this.damage; };

        this.getCell = 
            function(xCoord, yCoord)
            {
                for(var i = 0; i < parseInt(this.SIZE); i++)
                {  
                    if((parseInt(this.cells[i].x) === parseInt(xCoord)) && (parseInt(this.cells[i].y) === parseInt(yCoord)))    
                    {
                        //alert("inside get cell " + this.cells[i].x + " y is " + this.cells[i].y);
                        return this.cells[i];
                        
                    }

                }

                 return null;

            };
        
        
        this.isDestroyed = 
            function ()
            {
                //alert("This damage is " + this.damage + "this size is " + this.SIZE);
                //alert("" + this.shipType + " is destroyed is " + (this.damage >= this.SIZE));
                return this.damage >= this.SIZE;
            };

    }    
            
            
    function Carrier() 
    {
        Piece.call(this, 5);
        this.shipType = "Carrier";    
    }

    function Battleship() 
    {
        Piece.call(this, 4);
        this.shipType = "Battleship";
    }

    function Cruiser() 
    {
        Piece.call(this, 3);
        this.shipType = "Cruiser";
    }

    function Submarine() 
    {
        Piece.call(this, 3);
        this.shipType = "Submarine";
    }

    function Destroyer() 
    {
        Piece.call(this, 2);
        this.shipType = "Destroyer";  
    }


    function Cell(sourceImage) 
    {
        this.damaged = false;
        this.src = sourceImage;
        this.x = -1;
        this.y = -1;

        this.setXandY =
            function(xCoord, yCoord)
            {
                this.x = xCoord;
                this.y = yCoord;
            }; 

        this.damageCell =
            function ()
            {
                var temp, tempSub;
        
               if(playerTurn)
               {
                    document.getElementById("op" + this.x + "-" + this.y).src = "Images/FakeBlank2.png";
               }else
               {
                   temp = document.getElementById("" + this.x + "-" + this.y).src;
                    tempSub = temp.substring(parseInt(temp.length-5), parseInt(temp.length));
                    document.getElementById("" + this.x + "-" + this.y).src =  temp.substr(0, parseInt(temp.length-5)) + "Hit" + tempSub;
                   
               }
                    
            };
    
    }    